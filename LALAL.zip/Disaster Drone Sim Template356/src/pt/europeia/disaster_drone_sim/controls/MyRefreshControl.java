package pt.europeia.disaster_drone_sim.controls;

import java.util.ArrayList;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import pt.europeia.disaster_drone_api.dao.DisasterDao;
import pt.europeia.disaster_drone_api.model.Grid;
import pt.europeia.disaster_drone_api.model.RefreshControl;
import pt.europeia.disaster_drone_sim.models.Drone;
import pt.europeia.disaster_drone_sim.models.Fire;
import pt.europeia.disaster_drone_sim.models.InfoBoard;

public class MyRefreshControl extends RefreshControl {

	private Image droneImg;
	private Image ios_emoji_fire;


	public MyRefreshControl() {


	}

	@Override	
	public void initialize() {
		droneImg = new Image("droneImg.png");
		//droneImg = new Image("ios_emoji_fire.png");

		
		
		
		viewControl.setTitle("GUARDA FLORESTAL");
		
		
		
		viewControl.setPad00Name("");
		viewControl.setPad01Name("UP");
		viewControl.setPad02Name("");
		viewControl.setPad10Name("LEFT");
		viewControl.setPad11Name("APAGAR");
		viewControl.setPad12Name("RIGHT");
		viewControl.setPad20Name("");
		viewControl.setPad21Name("DOWN");
		viewControl.setPad22Name("SEARCH");
		viewControl.setPad30Name("");
		viewControl.setPad31Name("");
		viewControl.setPad32Name("");


	}


	@Override
	public void refresh() {
		GraphicsContext gc = viewControl.canvas.getGraphicsContext2D();
		double width = viewControl.canvas.getWidth();
		double height = viewControl.canvas.getHeight();
		


		
		gc.setFill(Color.WHITE);
		gc.fillRect(0,0,width,height);

// desenha grafico

		Grid grid = DisasterDao.getGrid();
		viewControl.setOutputText("GRID: "+grid.getX()+
				" - "+grid.getY());

		 
		double espacamentoX = width/grid.getX();
		double espacamentoY = height/ grid.getY();
		
		
		
		for(double i=0; i <= width; i=i+espacamentoX){
			gc.strokeLine(0+i, 0, 0+i , height);
		}
		for(double i=0; i <= height; i=i+ espacamentoY){
			gc.strokeLine(0, 0+i,width , 0+i );
		}
		

			

		
		
		
		atualizarNumeroFogos();
	
	


 
		
		
		
	Fogo f = DisasterDao.getFires(x, y)
		
		
		
		
		Drone d = InfoBoard.getDrone();

		gc.drawImage(droneImg,d.getX(),d.getY(),20,20);
}
		



	@Override
	public void refreshSlow() {
	}

	private void atualizarNumeroFogos() {
		
			if(viewControl.getSelectedListOpt() != null && viewControl.getSelectedListOpt().equals("Fogos")){
				ArrayList<Object> listaFogos = InfoBoard.getNumeroFogos();
				int auxiliar = 0;
				for(int i = 0; i < InfoBoard.getFireList().size(); i++){
					auxiliar++;
				}
				listaFogos.clear();
				listaFogos.add("Fogos Existentes: "+auxiliar);
			}
			viewControl.setListHTML(InfoBoard.getFireList());
		}	
}

